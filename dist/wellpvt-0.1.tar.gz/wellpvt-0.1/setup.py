from setuptools import setup

setup(name='wellpvt'
      , version='0.1'
      , description='Production well PVT calculations' 
      , packages=['wellpvt'] 
      , zip_safe=False)